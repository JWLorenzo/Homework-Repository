#include<stdio.h>
float x, y;
int AddXY (float x,float y){
        printf("X+Y: %.0f\n",x+y);
        return 0;
}
    
int SubXY (float x,float y){
        printf("X-Y: %.0f\n",x-y);
        return 0;
}
int MulXY (float x,float y){
        printf("X*Y: %.0f\n",x*y);
        return 0;
}
int DivXY (float x,float y){
       printf("X/Y: %.2f\n",x/y);
       return 0;
}
int main() {
    printf("Enter two integers(x,y): ");
    scanf("%f %f", &x, &y);
    AddXY (x,y);
    SubXY (x,y);
    MulXY (x,y);
    DivXY (x,y);
    return 0;
}
