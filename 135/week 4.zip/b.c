#include<stdio.h>
int a, b, c;
char name[] = "name";
void
swap (int *x, int *y)
{

  int temp;
  temp = *x;
  *x = *y;
  *y = temp;
}

void
rankStudentGrades ()
{
  if (a > c)
    swap ((int *) &a, (int *) &c);

  if (a > b)
    swap ((int *) &a, (int *) &b);

  if (b > c)
    swap ((int *) &b, (int *) &c);
}

int
main ()
{
  printf ("Enter student's name=");
  scanf ("%[^\n]s", name);
  printf ("\nEnter student's first grade=\n");
  scanf ("%d", &a);
  printf ("Enter student's second grade=\n");
  scanf ("%d", &b);
  printf ("Enter student's third grade=\n");
  scanf ("%d", &c);
  rankStudentGrades ();
  printf ("%s %d %d %d %.2f", name, a, b, c,(float)(a+b+c)/3);
  return 0;
}
