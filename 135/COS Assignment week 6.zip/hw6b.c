//Jacob Lorenzo
//This program takes in a password and determines if it's a valid password or not, if it's a valid password, the program encrypts it.
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
char password[128];
//This sets up the password string, 128 could be larger, but that is the value I chose
int reasonCt, condit1, condit2;
//reasonCt is used for the reasonx: printed for invalid passwords
//condit1 and 2 are used for stopping the if conditions in the for loop later on
//for the letter checker.
//lengthCheck checks the length of the password using strlen.
int lengthCheck (char password[]){
if (strlen (password) >= 8){
return 1;

}else{
return 0;
}
}

//upLowCheck checks for capital and lowercase letters in the password using a for loop with
//two if conditions.
int upLowCheck (char password[]){
for (int i = 0; password[i] != '\0'; i++){
if (((password[i] >= 'a' && password[i] <= 'z') == 1) && condit1 != 1){
condit1++;
}if (((password[i] >= 'A' && password[i] <= 'Z') == 1) && condit2 != 1){
condit2++;
}if ((condit1 == 1) && (condit2 == 1)){
return 1;
//This will only return 1 if both condit1 and condit2 are one meaning a capital and 
//lowercase exist in the password.
}
}
return 0;
}


int digCheck (char password[]){
for (int i = 0; password[i] != '\0'; i++){
if ((isdigit (password[i])) != 0){
//This uses a for loop with the isdigit function to determine if there is an number
//the isdigit function will return 1 if the isdigit returns a number greater than
//0 meaning that there is a number.
return 1;
}
}
return 0;
}


int charCheck (char password[]){
if (strstr (password, "@") != NULL 
       ||
strstr (password, "!") != NULL 
       ||
strstr (password, "#") != NULL 
       ||
strstr (password, "$") != NULL)
    {
//strstr is incredibly useful because it searches the entire string without a 
//for loop, as long as it doesn't return null, we have one of the characters.
return 1;
}else{
return 0;
}
}

int main (){
printf ("Please enter your preferred password: ");
scanf ("%s", password);

if (lengthCheck (password) == 1 && upLowCheck (password) == 1 
&&digCheck (password) == 1 && charCheck (password) == 1){
//This if statement determines if the functions above all return 1.   
printf ("Valid\n");
      
for (int i = 0; password[i] != '\0'; i++){
if (((password[i] >= 'a' && password[i] <= 'z') == 1)|((password[i] >= 'A' 
&& password[i] <= 'Z') == 1)){
//Similar to checking for capital and lowercase letters, but merged into one if
//statement.
password[i] += 1;
}if ((isdigit (password[i])) != 0){
password[i] += 1;
//The isdigit stayed the same because it was already built for a for loop.
}if ((password[i] == 64)//@
	      |
(password[i] == 33)//!
	      |
(password[i] == 35)//#
	      |
(password[i] == 36))//$
{
//I'm using the characters ascii values for the comparison
password[i] -= 1;
}
}
printf ("Encrypted Password: %s\n", password);
exit (0);	
//This exits the program so it doesn't try to go to the else statement
}else{
printf ("Invalid\n");
}
//This series of if statements uses reasonCt to keep track of the number of reasons
//that the password cannot be used, if the functions return a non 1 value, that 
//means that the password is missing that functions criteria.
if (lengthCheck (password) != 1){
reasonCt++;
printf("Reason%d: your password should contain at least eight characters.\n", 
reasonCt);
}
  
if (upLowCheck (password) != 1){
reasonCt++;
printf("Reason%d: your password should contain at least one uppercase and at least one lowercase letter.\n",
reasonCt);
}if (digCheck (password) != 1){
reasonCt++;
printf ("Reason%d: your password should contain at least one digit.\n",
reasonCt);
}if (charCheck (password) != 1){
reasonCt++;
printf("Reason%d: your password should contain at least one of the four special characters \"! @ # $\" \n",
reasonCt);
}
return 0;
}


 
 
 
 
