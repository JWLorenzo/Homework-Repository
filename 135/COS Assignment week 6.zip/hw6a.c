﻿//Jacob Lorenzo
//This code takes in a numerical input and produces every number in the fibonacci sequence that is less than or equal to the numerical input.
#include <stdio.h>
int i, check1, check2, buffer1 = 0, buffer2 = 1, next = 0;
//i is a counter, check 1 & 2 are used for checking if the input is valid
//buffer 1 and 2 are used to keep a buffer of the two previous fib numbers
//next is used for the next number in the sequence

int 
main () 
{
printf ("Enter a number:");
scanf ("\n%d", &check1);
check2 = (int) check1;
  
 
if (check2 == check1 && (!(check2 == 0) && !((int) check1 == 0))&& (check2 >= 1)){
//checks to make sure that the input is valid
printf ("Fibonacci Series: %d,%d", buffer1, buffer2);
//prints 1 and 0 at the start
next = buffer1 + buffer2;

while (next <= check1){
printf (",%d", next);
buffer1 = buffer2;
buffer2 = next;
next = buffer1 + buffer2;
//the while loop will keep printing values in the fibonacci sequence until it's
//greater than the  initial input
}

}else{
printf("Invalid input - please try a positive integer.\n");
}
return 0;
}


